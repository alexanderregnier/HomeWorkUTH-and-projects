from cls_BD_MySQL import *

LABD = BD_MySQL('root', '', '127.0.0.1', 'labd')
APP_NAME = "Login 2024 - JPD"
