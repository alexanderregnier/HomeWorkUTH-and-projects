import tkinter
tkinter._test()
