from tkinter import *

app = Tk()
# texto = Label(app, text="Hola Mundo!")
# texto.pack()

texto = Label(app, text="Hola Mundo!").pack()

app.mainloop()